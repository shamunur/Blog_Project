-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 23, 2024 at 01:26 AM
-- Server version: 8.2.0
-- PHP Version: 8.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog-project`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `categories` varchar(255) NOT NULL,
  `user_id` int NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `content`, `image`, `tags`, `categories`, `user_id`, `created_date`) VALUES
(1, '8 Types of Logos — Which is Right For Your Business?', 'QProin faucibus nec mauris a sodales, sed elementum mi tincidunt. Sed eget viverra egestas nisi in consequat. As technology continues to advance at a rapid pace, the way we work and interact with our devices is also changing. One area that has seen significant growth in recent years is the intersection of user experience (UX) and user interface (UI) design, artificial intelligence (AI), and the modern work station.\r\n\r\nIn this blog post, we will explore how these three elements are coming together to revolutionize the workplace.Nulla aliquam rerum nesciunt velit iusto. Deserunt fugiat tempora sed voluptatibus neque suscipit minima qui. Beatae ipsa autem adipisci. Iusto numquam maxime vitae natus molestiae.\r\n\r\nUX/UI design refers to the process of designing products, such as software, that are easy to use and intuitive for the user. This includes everything from the layout of buttons and menus to the overall aesthetic of the product. In the workplace, good UX/UI design can make a huge difference in terms of productivity and user satisfaction.\r\n\r\nAI, on the other hand, is the simulation of human intelligence in machines. It has the potential to automate many tasks and make them more efficient. In the workplace, AI can be used to assist with tasks such as scheduling, data analysis, and customer service.', 'uploads/blog-details-big-img-2.jpg', 'Landing, Tech', 'Design', 3, '2024-05-23 00:32:38'),
(2, '16 witty tips to get six-figure clients on Dribbble', 'QProin faucibus nec mauris a sodales, sed elementum mi tincidunt. Sed eget viverra egestas nisi in consequat. As technology continues to advance at a rapid pace, the way we work and interact with our devices is also changing. One area that has seen significant growth in recent years is the intersection of user experience (UX) and user interface (UI) design, artificial intelligence (AI), and the modern work station.\r\n\r\nIn this blog post, we will explore how these three elements are coming together to revolutionize the workplace.Nulla aliquam rerum nesciunt velit iusto. Deserunt fugiat tempora sed voluptatibus neque suscipit minima qui. Beatae ipsa autem adipisci. Iusto numquam maxime vitae natus molestiae.\r\n\r\nUX/UI design refers to the process of designing products, such as software, that are easy to use and intuitive for the user. This includes everything from the layout of buttons and menus to the overall aesthetic of the product. In the workplace, good UX/UI design can make a huge difference in terms of productivity and user satisfaction.\r\n\r\nAI, on the other hand, is the simulation of human intelligence in machines. It has the potential to automate many tasks and make them more efficient. In the workplace, AI can be used to assist with tasks such as scheduling, data analysis, and customer service.', 'uploads/blog-details-big-img-3.jpeg', 'Landing, Tech', 'Design', 3, '2024-05-23 00:32:38'),
(3, 'Spacex lunch a rocket for moon', 'QProin faucibus nec mauris a sodales, sed elementum mi tincidunt. Sed eget viverra egestas nisi in consequat. As technology continues to advance at a rapid pace, the way we work and interact with our devices is also changing. One area that has seen significant growth in recent years is the intersection of user experience (UX) and user interface (UI) design, artificial intelligence (AI), and the modern work station.\r\n\r\nIn this blog post, we will explore how these three elements are coming together to revolutionize the workplace.Nulla aliquam rerum nesciunt velit iusto. Deserunt fugiat tempora sed voluptatibus neque suscipit minima qui. Beatae ipsa autem adipisci. Iusto numquam maxime vitae natus molestiae.\r\n\r\nUX/UI design refers to the process of designing products, such as software, that are easy to use and intuitive for the user. This includes everything from the layout of buttons and menus to the overall aesthetic of the product. In the workplace, good UX/UI design can make a huge difference in terms of productivity and user satisfaction.\r\n\r\nAI, on the other hand, is the simulation of human intelligence in machines. It has the potential to automate many tasks and make them more efficient. In the workplace, AI can be used to assist with tasks such as scheduling, data analysis, and customer service.', 'uploads/blog-details-big-img-4.jpeg', 'Landing', 'Tech', 3, '2024-05-23 00:32:38'),
(4, 'voyager 1 says goodbye to us', 'QProin faucibus nec mauris a sodales, sed elementum mi tincidunt. Sed eget viverra egestas nisi in consequat. As technology continues to advance at a rapid pace, the way we work and interact with our devices is also changing. One area that has seen significant growth in recent years is the intersection of user experience (UX) and user interface (UI) design, artificial intelligence (AI), and the modern work station.\r\n\r\nIn this blog post, we will explore how these three elements are coming together to revolutionize the workplace.Nulla aliquam rerum nesciunt velit iusto. Deserunt fugiat tempora sed voluptatibus neque suscipit minima qui. Beatae ipsa autem adipisci. Iusto numquam maxime vitae natus molestiae.\r\n\r\nUX/UI design refers to the process of designing products, such as software, that are easy to use and intuitive for the user. This includes everything from the layout of buttons and menus to the overall aesthetic of the product. In the workplace, good UX/UI design can make a huge difference in terms of productivity and user satisfaction.\r\n\r\nAI, on the other hand, is the simulation of human intelligence in machines. It has the potential to automate many tasks and make them more efficient. In the workplace, AI can be used to assist with tasks such as scheduling, data analysis, and customer service.', 'uploads/blog-details-big-img-5.jpeg', 'Landing', 'Creative', 3, '2024-05-23 00:32:38'),
(5, 'Indus valley people vanished, Why?', 'QProin faucibus nec mauris a sodales, sed elementum mi tincidunt. Sed eget viverra egestas nisi in consequat. As technology continues to advance at a rapid pace, the way we work and interact with our devices is also changing. One area that has seen significant growth in recent years is the intersection of user experience (UX) and user interface (UI) design, artificial intelligence (AI), and the modern work station.\r\n\r\nIn this blog post, we will explore how these three elements are coming together to revolutionize the workplace.Nulla aliquam rerum nesciunt velit iusto. Deserunt fugiat tempora sed voluptatibus neque suscipit minima qui. Beatae ipsa autem adipisci. Iusto numquam maxime vitae natus molestiae.\r\n\r\nUX/UI design refers to the process of designing products, such as software, that are easy to use and intuitive for the user. This includes everything from the layout of buttons and menus to the overall aesthetic of the product. In the workplace, good UX/UI design can make a huge difference in terms of productivity and user satisfaction.\r\n\r\nAI, on the other hand, is the simulation of human intelligence in machines. It has the potential to automate many tasks and make them more efficient. In the workplace, AI can be used to assist with tasks such as scheduling, data analysis, and customer service.', 'uploads/blog-details-big-img-6.jpeg', 'Creative', 'Tech', 3, '2024-05-23 00:32:38'),
(6, 'Chernobyl disaster, how it happend', 'QProin faucibus nec mauris a sodales, sed elementum mi tincidunt. Sed eget viverra egestas nisi in consequat. As technology continues to advance at a rapid pace, the way we work and interact with our devices is also changing. One area that has seen significant growth in recent years is the intersection of user experience (UX) and user interface (UI) design, artificial intelligence (AI), and the modern work station.\r\n\r\nIn this blog post, we will explore how these three elements are coming together to revolutionize the workplace.Nulla aliquam rerum nesciunt velit iusto. Deserunt fugiat tempora sed voluptatibus neque suscipit minima qui. Beatae ipsa autem adipisci. Iusto numquam maxime vitae natus molestiae.\r\n\r\nUX/UI design refers to the process of designing products, such as software, that are easy to use and intuitive for the user. This includes everything from the layout of buttons and menus to the overall aesthetic of the product. In the workplace, good UX/UI design can make a huge difference in terms of productivity and user satisfaction.\r\n\r\nAI, on the other hand, is the simulation of human intelligence in machines. It has the potential to automate many tasks and make them more efficient. In the workplace, AI can be used to assist with tasks such as scheduling, data analysis, and customer service.', 'uploads/blog-details-big-img-7.jpeg', 'Creative', 'Development', 3, '2024-05-23 00:32:38'),
(7, 'Complete Guide to User Flow in UX Design', 'QProin faucibus nec mauris a sodales, sed elementum mi tincidunt. Sed eget viverra egestas nisi in consequat. As technology continues to advance at a rapid pace, the way we work and interact with our devices is also changing. One area that has seen significant growth in recent years is the intersection of user experience (UX) and user interface (UI) design, artificial intelligence (AI), and the modern work station.\r\n\r\nIn this blog post, we will explore how these three elements are coming together to revolutionize the workplace.Nulla aliquam rerum nesciunt velit iusto. Deserunt fugiat tempora sed voluptatibus neque suscipit minima qui. Beatae ipsa autem adipisci. Iusto numquam maxime vitae natus molestiae.\r\n\r\nUX/UI design refers to the process of designing products, such as software, that are easy to use and intuitive for the user. This includes everything from the layout of buttons and menus to the overall aesthetic of the product. In the workplace, good UX/UI design can make a huge difference in terms of productivity and user satisfaction.\r\n\r\nAI, on the other hand, is the simulation of human intelligence in machines. It has the potential to automate many tasks and make them more efficient. In the workplace, AI can be used to assist with tasks such as scheduling, data analysis, and customer service.', 'uploads/blog-details-big-img-8.jpeg', 'Creative', 'Tech', 3, '2024-05-23 00:32:38'),
(8, 'Rental Friendly Practices for your Guests', 'QProin faucibus nec mauris a sodales, sed elementum mi tincidunt. Sed eget viverra egestas nisi in consequat. As technology continues to advance at a rapid pace, the way we work and interact with our devices is also changing. One area that has seen significant growth in recent years is the intersection of user experience (UX) and user interface (UI) design, artificial intelligence (AI), and the modern work station.\r\n\r\nIn this blog post, we will explore how these three elements are coming together to revolutionize the workplace.Nulla aliquam rerum nesciunt velit iusto. Deserunt fugiat tempora sed voluptatibus neque suscipit minima qui. Beatae ipsa autem adipisci. Iusto numquam maxime vitae natus molestiae.\r\n\r\nUX/UI design refers to the process of designing products, such as software, that are easy to use and intuitive for the user. This includes everything from the layout of buttons and menus to the overall aesthetic of the product. In the workplace, good UX/UI design can make a huge difference in terms of productivity and user satisfaction.\r\n\r\nAI, on the other hand, is the simulation of human intelligence in machines. It has the potential to automate many tasks and make them more efficient. In the workplace, AI can be used to assist with tasks such as scheduling, data analysis, and customer service.', 'uploads/blog-details-big-img-9.jpeg', 'Tech', 'Development', 3, '2024-05-23 00:32:38');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int NOT NULL,
  `message` text NOT NULL,
  `user_id` int NOT NULL,
  `blog_id` int NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `message`, `user_id`, `blog_id`, `created_date`) VALUES
(1, 'Digital content wrangler I UX enthusiast I Recovering educator I Shameless nerd & GIF connoisseur I Hockey fan.', 3, 1, '2024-05-23 01:11:41'),
(2, 'Additionally, AI-powered customer service can make it easier for employees to help customers and resolve issues. In conclusion, the intersection of UX/UI design, AI, and the modern work station is revolutionizing the way we work. By making the workplace more efficient, productive, and user-friendly, these three elements are helping to improve the overall work experience for employees and customers alike.', 3, 1, '2024-05-23 01:14:59'),
(3, 'Additionally, AI-powered customer service can make it easier for employees to help customers and resolve issues. In conclusion, the intersection of UX/UI design, AI, and the modern work station is revolutionizing the way we work. By making the workplace more efficient, productive, and user-friendly, these three elements are helping to improve the overall work experience for employees and customers alike.', 3, 2, '2024-05-23 01:19:20'),
(4, '\r\nAI, on the other hand, is the simulation of human intelligence in machines. It has the potential to automate many tasks and make them more efficient. In the workplace, AI can be used to assist with tasks such as scheduling, data analysis, and customer service.', 3, 3, '2024-05-23 01:19:33'),
(5, 'AI, on the other hand, is the simulation of human intelligence in machines. It has the potential to automate many tasks and make them more efficient. In the workplace, AI can be used to assist with tasks such as scheduling, data analysis, and customer service.', 3, 4, '2024-05-23 01:19:48'),
(6, 'AI, on the other hand, is the simulation of human intelligence in machines. It has the potential to automate many tasks and make them more efficient. In the workplace, AI can be used to assist with tasks such as scheduling, data analysis, and customer service.\r\n', 3, 5, '2024-05-23 01:19:57'),
(7, 'Additionally, AI-powered customer service can make it easier for employees to help customers and resolve issues. In conclusion, the intersection of UX/UI design, AI, and the modern work station is revolutionizing the way we work. By making the workplace more efficient, productive, and user-friendly, these three elements are helping to improve the overall work experience for employees and customers alike.', 3, 5, '2024-05-23 01:20:04'),
(8, 'Additionally, AI-powered customer service can make it easier for employees to help customers and resolve issues. In conclusion, the intersection of UX/UI design, AI, and the modern work station is revolutionizing the way we work. By making the workplace more efficient, productive, and user-friendly, these three elements are helping to improve the overall work experience for employees and customers alike.', 3, 6, '2024-05-23 01:20:12'),
(9, 'Additionally, AI-powered customer service can make it easier for employees to help customers and resolve issues. In conclusion, the intersection of UX/UI design, AI, and the modern work station is revolutionizing the way we work. By making the workplace more efficient, productive, and user-friendly, these three elements are helping to improve the overall work experience for employees and customers alike.', 3, 7, '2024-05-23 01:20:18'),
(10, 'Additionally, AI-powered customer service can make it easier for employees to help customers and resolve issues. In conclusion, the intersection of UX/UI design, AI, and the modern work station is revolutionizing the way we work. By making the workplace more efficient, productive, and user-friendly, these three elements are helping to improve the overall work experience for employees and customers alike.', 3, 8, '2024-05-23 01:20:24'),
(11, 'Additionally, AI-powered customer service can make it easier for employees to help customers and resolve issues. In conclusion, the intersection of UX/UI design, AI, and the modern work station is revolutionizing the way we work. ', 3, 8, '2024-05-23 01:20:31'),
(12, 'Additionally, AI-powered customer service can make it easier for employees to help customers and resolve issues. In conclusion, the intersection of UX/UI design, AI, and the modern work station is revolutionizing the way we work. ', 3, 1, '2024-05-23 01:20:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `bio` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `username`, `password`, `bio`, `image`, `created_date`) VALUES
(1, 'User Name', 'user@gmail.com', 'username', '123456', 'i am user', 'uploads/user-image.png', '2024-05-23 00:27:37'),
(2, 'Admin Name', 'admin@gmail.com', 'admin', '123456', 'i am admin', 'uploads/user-image.png', '2024-05-23 00:28:05'),
(3, 'Afroja Ritu Mone', 'afrojaritumone@gmail.com', 'afrojaritumone', '123456', 'I am Afroja Ritu Mone', 'uploads/user-image.png', '2024-05-23 00:28:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
