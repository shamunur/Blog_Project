<?php

include_once 'inc/config.php';
include_once 'layout/header.php';

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM `blogs`";
$run = mysqli_query($connect, $sql);

if (isset($_POST['delete_post'])) {
    $post_id = $_POST['id'];
    $image = $_POST['image'];
    $sql = "DELETE FROM `blogs` WHERE `blogs`.`id` = $post_id";
    $run = mysqli_query($connect, $sql);
    if ($run) {
        unlink($image);
        $_SESSION['success'] = "Post has been deleted";
        header('location: blogs.php');
    }else{
        $_SESSION['error'] = "Something went wrong";
        header('location: blogs.php');
    }
}

?>

    <div class="user-dashboard p-t-100 p-b-100">
        <div class="container">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success m-t-20" role="alert">
                    <?php
                    echo $_SESSION['success'];
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger m-t-20" role="alert">
                    <?php
                    echo $_SESSION['error'];
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['user_name'])): ?>
                <div class="row m-b-xs-30">
                    <div class="col-xl-6 col-md-6">
                        <div class="dashboard-title">
                            <h2>All Blogs</h2>
                        </div>
                    </div>
                    <div class="col-xl-6 col-md-6 text-md-end">
                        <a href="add-blog.php" class="btn btn-primary">Add Blog</a>
                    </div>
                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-xl-12">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="table-dark">
                            <tr style="text-align: center;">
                                <th scope="col">#</th>
                                <th scope="col">Image</th>
                                <th scope="col">Title</th>
                                <th scope="col">Content</th>
                                <th scope="col">Tags</th>
                                <th scope="col">Categories</th>
                                <th scope="col">Created Date</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            if (mysqli_num_rows($run) > 0):
                                $count = 1;
                                while ($row = mysqli_fetch_assoc($run)):
                                    if ($user_id == $row['user_id']):
                                        ?>
                                        <tr>
                                            <th scope="row"><?php echo $count; ?></th>
                                            <td>
                                                <?php if(!empty($row['image'])): ?>
                                                    <img width="100" src="<?php echo $row['image'] ?>" alt="thumb">
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo $row['title'] ?></td>
                                            <td>
                                                <?php echo strip_tags(substr($row['content'], 0, 100)) . '...'; ?>
                                            </td>
                                            <td><?php echo $row['tags'] ?></td>
                                            <td><?php echo $row['categories'] ?></td>
                                            <td><?php echo $row['created_date'] ?></td>
                                            <td>
                                                <div class="d-flex justify-content-center gap-3">
                                                    <a href="edit-blog.php?id=<?php echo $row['id']?>" class="btn btn-primary">
                                                        Edit
                                                    </a>
                                                    <form method="post" onsubmit="return confirm('are you sure to delete?')">
                                                        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                                                        <input type="hidden" name="image" value="<?php echo $row['image'] ?>">
                                                        <button name="delete_post" type="submit" class="btn btn-danger">Delete
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php
                                    endif;
                                    $count++;
                                endwhile;
                            endif;
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include_once 'layout/footer.php'; ?>