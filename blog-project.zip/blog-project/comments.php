<?php

include_once 'inc/config.php';
include_once 'layout/header.php';

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM `comments`";
$run = mysqli_query($connect, $sql);
$rows = mysqli_num_rows($run);

if (isset($_POST['delete_comment'])) {
    $comment_id = $_POST['id'];
    $sql = "DELETE FROM `comments` WHERE `comments`.`id` = $comment_id";
    $run = mysqli_query($connect, $sql);
    if ($run) {
        $_SESSION['success'] = "Post has been deleted";
        header('location: comments.php');
    }else{
        $_SESSION['error'] = "Something went wrong";
        header('location: comments.php');
    }
}

?>

    <div class="user-dashboard p-t-100 p-b-100">
        <div class="container">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success m-t-20" role="alert">
                    <?php
                    echo $_SESSION['success'];
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger m-t-20" role="alert">
                    <?php
                    echo $_SESSION['error'];
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['user_name'])): ?>
                <div class="row">
                    <div class="col-xl-6">
                        <div class="dashboard-title">
                            <h2>All Comments</h2>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-xl-12">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="table-dark">
                            <tr style="text-align: center;">
                                <th scope="col">#</th>
                                <th scope="col">Message</th>
                                <th scope="col">Blog Title</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            if ($rows):
                                $count = 1;
                                while ($row = mysqli_fetch_assoc($run)):
                                    $blog_id = $row['blog_id'];
                                    if ($user_id == $row['user_id']):
                                        ?>
                                        <tr>
                                            <th scope="row"><?php echo $count; ?></th>
                                            <td><?php echo $row['message'] ?></td>
                                            <td>

                                                <?php

                                                $sql = "SELECT * FROM `blogs` WHERE `id` = $blog_id";
                                                $query = mysqli_query($connect, $sql);
                                                $result = mysqli_fetch_array($query);
                                                echo $result['title'];
                                                ?>
                                            </td>
                                            <td>
                                                <div class="d-flex justify-content-center gap-3">
                                                    <form method="post" onsubmit="return confirm('are you sure to delete?')">
                                                        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                                                        <button name="delete_comment" type="submit" class="btn btn-danger">Delete
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php
                                    endif;
                                    $count++;
                                endwhile;
                            endif;
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include_once 'layout/footer.php'; ?>