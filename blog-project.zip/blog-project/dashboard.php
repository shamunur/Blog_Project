<?php

include_once 'inc/config.php';
include_once 'layout/header.php';

if (!isset($_SESSION['user_name'])) {
    header('location: login.php');
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM `users` WHERE `users`.`id` = $user_id";
$run = mysqli_query($connect, $sql);
$rows = mysqli_num_rows($run);

?>


    <div class="user-dashboard p-t-200 p-b-200">
        <div class="container">
            <?php if (isset($_SESSION['user_name'])): ?>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="dashboard-title">
                            <h2>Welcome to <?php echo $_SESSION['user_name']; ?></h2>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-xl-12">
                    <table class="table">
                        <tbody>
                        <?php
                        if ($rows):
                            while ($row = mysqli_fetch_assoc($run)):
                                ?>
                                <tr>
                                    <th class="table-dark text-center" scope="col">#</th>
                                    <td class="px-5">
                                        <?php if (!empty($row['id'])): ?>
                                            <?php echo $row['id'] ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="table-dark text-center" scope="col">Image</th>
                                    <td class="px-5">
                                        <?php if (!empty($row['image'])): ?>
                                            <img width="100" src="<?php echo $row['image'] ?>" alt="thumb">
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="table-dark text-center" scope="col">Full Name</th>
                                    <td class="px-5">
                                        <?php if (!empty($row['full_name'])): ?>
                                            <?php echo $row['full_name'] ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="table-dark text-center" scope="col">Email</th>
                                    <td class="px-5">
                                        <?php if (!empty($row['email'])): ?>
                                            <?php echo $row['email'] ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="table-dark text-center" scope="col">Username</th>
                                    <td class="px-5">
                                        <?php if (!empty($row['username'])): ?>
                                            <?php echo $row['username'] ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="table-dark text-center" scope="col">Password</th>
                                    <td class="px-5">
                                        <?php if (!empty($row['password'])): ?>
                                            <?php echo $row['password'] ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="table-dark text-center" scope="col">Bio</th>
                                    <td class="px-5">
                                        <?php if (!empty($row['bio'])): ?>
                                            <?php echo $row['bio'] ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php
                            endwhile;
                        endif;
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


<?php include_once 'layout/footer.php'; ?>