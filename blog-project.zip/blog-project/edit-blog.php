<?php

include_once 'inc/config.php';
include_once 'layout/header.php';

$user_id = $_SESSION['user_id'];
$edit_post_id = $_GET['id'];

$sql = "SELECT * FROM `blogs` WHERE `id` = $edit_post_id";
$query = mysqli_query($connect, $sql);
$result = mysqli_fetch_array($query);

$old_image = $result['image'];

if (isset($_POST['update_blog'])) {
    $title = mysqli_real_escape_string($connect, $_POST['title']);
    $content = mysqli_real_escape_string($connect, $_POST['content']);
    $tags = mysqli_real_escape_string($connect, $_POST['tags']);
    $categories = mysqli_real_escape_string($connect, $_POST['categories']);

    $file_name = $_FILES['image']['name'];
    $temp_name = $_FILES['image']['tmp_name'];
    $size = $_FILES['image']['size'];
    $image_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    $allowed = array('jpg', 'jpeg', 'png', 'gif');
    $destination = 'uploads/' . $file_name;

    if (!empty($file_name)){

        if (in_array($image_extension, $allowed)) {
            if ($size < 20000000) {
                unlink($result['image']);
                move_uploaded_file($temp_name, $destination);
            } else {
                $_SESSION['error'] = "Sorry, your file is too large.";
            }
        } else {
            $_SESSION['error'] = " File format not allowed ";
        }

        if (!empty($title) && !empty($categories) && !empty($tags) && !empty($content)) {
            $sql = "UPDATE `blogs` SET `title`= '${title}' ,`content`= '${content}',`image`= '${destination}' ,`tags`= '${tags}',`categories`='${categories}',user_id = '${user_id}' WHERE id = $edit_post_id";
            $query = mysqli_query($connect, $sql);
            if ($query) {
                $_SESSION['success'] = "Your blog has been updated successfully";
                header('location: blogs.php');
            } else {
                $_SESSION['error'] = "Something went wrong";
            }
        } else {
            $_SESSION['error'] = "Please fill all the fields";
        }
    }else{
        if (!empty($title) && !empty($categories) && !empty($tags) && !empty($content)) {
            $sql = "UPDATE `blogs` SET `title`= '${title}' ,`content`= '${content}',`image`= '${old_image}' ,`tags`= '${tags}',`categories`='${categories}',user_id = '${user_id}' WHERE id = $edit_post_id";
            $query = mysqli_query($connect, $sql);
            if ($query) {
                $_SESSION['success'] = "Your blog has been updated successfully";
                header('location: blogs.php');
            } else {
                $_SESSION['error'] = "Something went wrong";
            }
        } else {
            $_SESSION['error'] = "Please fill all the fields";
        }
    }


}

?>

    <div class="user-dashboard p-t-100 p-b-100">
        <div class="container">
            <div class="row">
                <div class="col-xl-6">
                    <div class="dashboard-title">
                        <h2>Edit Blog</h2>
                    </div>
                </div>
                <div class="col-xl-6 text-end">
                    <a href="blogs.php" class="btn btn-primary">Blog List</a>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12">
                    <div class="login-form">
                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-xl-12">
                                    <div class="input-wrap">
                                        <label for="title">Title</label>
                                        <input type="text" id="title" name="title" placeholder="Enter your Title"
                                               required value="<?php echo $result['title']?>">
                                    </div>
                                </div>
                                <div class="col-xl-12">
                                    <div class="input-wrap">
                                        <label for="content">Content</label>
                                        <textarea name="content" id="content" cols="30" rows="10"><?php echo $result['content']?></textarea>
                                    </div>
                                </div>
                                <div class="col-xl-12">
                                    <div class="input-wrap">
                                        <label for="image">Thumbnail</label>
                                        <input type="file" name="image" id="image">
                                        <img width="100" src="<?php echo $result['image']?>" alt="image">
                                    </div>
                                </div>
                                <div class="col-xl-6">
                                    <div class="input-wrap">
                                        <label for="tags">Tags</label>
                                        <input type="text" id="tags" name="tags" placeholder="Enter your Tags" required  value="<?php echo $result['tags']?>">
                                    </div>
                                </div>
                                <div class="col-xl-6">
                                    <div class="input-wrap">
                                        <label for="tags">Categories</label>
                                        <input type="text" id="categories" name="categories"
                                               placeholder="Enter your Categories" required  value="<?php echo $result['categories']?>">
                                    </div>
                                </div>
                                <div class="col-xl-12">
                                    <div class="input-btn">
                                        <button type="submit" name="update_blog">Update Blog</button>
                                    </div>
                                </div>
                                <div class="col-xl-12">
                                    <?php if (isset($_SESSION['success'])): ?>
                                        <div class="alert alert-success m-t-20" role="alert">
                                            <?php
                                            echo $_SESSION['success'];
                                            unset($_SESSION['success']);
                                            ?>
                                        </div>
                                    <?php endif; ?>

                                    <?php if (isset($_SESSION['error'])): ?>
                                        <div class="alert alert-danger m-t-20" role="alert">
                                            <?php
                                            echo $_SESSION['error'];
                                            unset($_SESSION['error']);
                                            ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include_once 'layout/footer.php'; ?>