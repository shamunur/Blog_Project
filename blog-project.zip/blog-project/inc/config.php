<?php

$connect = mysqli_connect("localhost", "root", "", "blog-project") or die("DB Not Connected");








