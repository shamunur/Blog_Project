<?php

include_once 'inc/config.php';
include_once 'layout/header.php';

$sql = "SELECT * FROM `blogs`";
$run = mysqli_query($connect, $sql);
?>

    <div class="blog-section p-t-100 p-b-100">
        <div class="container">
            <div class="row">
                <?php
                if (mysqli_num_rows($run) > 0):
                    while ($row = mysqli_fetch_assoc($run)):
                        ?>
                        <div class="col-xl-4 m-b-40">
                            <div class="blog-post">
                                <?php if (!empty($row['image'])): ?>
                                    <div class="thumb">
                                        <img src="<?php echo $row['image'] ?>" alt="thumb">
                                    </div>
                                <?php endif; ?>
                                <div class="content">
                                    <div class="meta">
                                        <div class="category"><?php echo $row['categories'] ?></div>
                                        <div class="date"><?php echo date('d-M-Y', strtotime($row['created_date'])); ?></div>
                                    </div>
                                    <h3>
                                        <a href="single_post.php?id=<?php echo $row['id'] ?>">
                                            <?php echo $row['title'] ?>
                                        </a>
                                    </h3>
                                    <div class="text">
                                        <?php echo strip_tags(substr($row['content'], 0, 200)) . '...'; ?>
                                    </div>
                                    <div class="read-more">
                                        <a href="single_post.php?id=<?php echo $row['id'] ?>">Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    endwhile;
                endif;
                ?>
            </div>
        </div>
    </div>

<?php include_once 'layout/footer.php'; ?>