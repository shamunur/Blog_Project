
<div class="bg-dark p-t-30 p-b-30">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="text-center text-white">Design & Develop Ritu ©2024 Blogs™</div>
            </div>
        </div>
    </div>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>