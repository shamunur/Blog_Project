<?php
$page = basename($_SERVER['PHP_SELF'], '.php');

session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Blog Project</title>
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/spacing.css">
    <link rel="stylesheet" href="assets/css/main.css">
</head>
<body>

<nav class="navbar navbar-expand-lg bg-dark p-t-20 p-b-20" data-bs-theme="dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">Blogs</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02"
                aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarColor02">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo ($page == 'index') ? 'active' : ''; ?>" href="index.php">
                        Home <span class="visually-hidden">(current)</span>
                    </a>
                </li>
                <?php if(isset($_SESSION['user_name'])): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($page == 'dashboard') ? 'active' : ''; ?>" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($page == 'blogs') ? 'active' : ''; ?>" href="blogs.php">Blogs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($page == 'comments') ? 'active' : ''; ?>" href="comments.php">Comments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($page == 'logout') ? 'active' : ''; ?>" href="logout.php">Logout</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($page == 'login') ? 'active' : ''; ?>" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($page == 'registration') ? 'active' : ''; ?>" href="registration.php">Registration</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>