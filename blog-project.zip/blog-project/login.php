<?php

include_once 'inc/config.php';
include_once 'layout/header.php';

if (isset($_SESSION['user_name'])) {
    header('location: dashboard.php');
}

?>

<div class="login-section p-t-200 p-b-200">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6">
                <div class="login-form">
                    <form action="" method="post">
                        <h2 class="title">Login your account</h2>
                        <div class="input-wrap">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" placeholder="Enter your Email" required>
                        </div>
                        <div class="input-wrap">
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" placeholder="Enter your password" required>
                        </div>
                        <div class="input-btn">
                            <button type="submit" name="login_btn">Login</button>
                        </div>

                        <?php if (isset($_SESSION['error'])): ?>
                            <div class="alert alert-danger m-t-20" role="alert">
                                <?php
                                echo $_SESSION['error'];
                                unset($_SESSION['error']);
                                ?>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once 'layout/footer.php'; ?>

<?php

if (isset($_POST['login_btn'])) {
    $email = mysqli_real_escape_string($connect, $_POST['email']);
    $password = mysqli_real_escape_string($connect, $_POST['password']);

    $sql = "SELECT * FROM users WHERE email = '{$email}' AND password = '{$password}'";

    $query = mysqli_query($connect, $sql);

    if (mysqli_num_rows($query) > 0) {
        $result = mysqli_fetch_assoc($query);
        $_SESSION['user_id'] = $result['id'];
        $_SESSION['user_name'] = $result['username'];
        $_SESSION['user_password'] = $result['password'];
        header('location: dashboard.php');
    } else {
        $_SESSION['error'] = "Login Failed";
        header('location: login.php');
    }
}

?>

