<?php

include_once 'inc/config.php';
include_once 'layout/header.php';

if (isset($_SESSION['user_name'])) {
    header('location: dashboard.php');
}

if (isset($_POST['register_btn'])) {
    $full_name = mysqli_real_escape_string($connect, $_POST['full_name']);
    $email = mysqli_real_escape_string($connect, $_POST['email']);
    $username = mysqli_real_escape_string($connect, $_POST['username']);
    $password = mysqli_real_escape_string($connect, $_POST['password']);
    $bio = mysqli_real_escape_string($connect, $_POST['bio']);

    $file_name = $_FILES['image']['name'];
    $temp_name = $_FILES['image']['tmp_name'];
    $size = $_FILES['image']['size'];
    $image_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    $allowed = array('jpg', 'jpeg', 'png', 'gif');
    $destination = 'uploads/' . $file_name;

    if (in_array($image_extension, $allowed)) {
        if ($size < 20000000) {
            move_uploaded_file($temp_name, $destination);
        } else {
            $_SESSION['error'] = "Sorry, your file is too large.";
        }
    } else {
        $_SESSION['error'] = " File format not allowed ";
    }

    if (!empty($full_name) && !empty($email) && !empty($username) && !empty($password) && !empty($bio) && !empty($file_name)) {
        $sql = "INSERT INTO users(full_name, email, username, password, bio, image) VALUES('{$full_name}', '{$email}', '{$username}', '{$password}', '{$bio}', '{$destination}')";
        $query = mysqli_query($connect, $sql);
        if ($query) {
            $_SESSION['success'] = "Your account has been created";
            header('location: login.php');
        } else {
            $_SESSION['error'] = "Something went wrong";
        }
    } else {
        $_SESSION['error'] = "Please fill all the fields";
    }
}

?>

<div class="login-section p-t-100 p-b-100">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6">
                <div class="login-form">
                    <form action="" method="post" enctype="multipart/form-data">
                        <h2 class="title">Create Your Account</h2>
                        <div class="input-wrap">
                            <label for="full_name">Full Name</label>
                            <input type="text" id="full_name" name="full_name" placeholder="Enter your Full Name"
                                   required>
                        </div>
                        <div class="input-wrap">
                            <label for="email">Email</label>
                            <input type="email" name="email" placeholder="Enter your Email" required>
                        </div>
                        <div class="input-wrap">
                            <label for="username">Username</label>
                            <input type="text" name="username" placeholder="Enter your Username" required>
                        </div>
                        <div class="input-wrap">
                            <label for="password">Password</label>
                            <input type="password" name="password" placeholder="Enter your password" required>
                        </div>
                        <div class="input-wrap">
                            <label for="bio">Bio</label>
                            <textarea name="bio" id="bio" cols="30" rows="10"></textarea>
                        </div>
                        <div class="input-wrap">
                            <label for="image">Profile Photo</label>
                            <input type="file" name="image">
                        </div>
                        <div class="input-btn">
                            <button type="submit" name="register_btn">Create Account</button>
                        </div>

                        <?php if (isset($_SESSION['success'])): ?>
                            <div class="alert alert-success m-t-20" role="alert">
                                <?php
                                echo $_SESSION['success'];
                                unset($_SESSION['success']);
                                ?>
                            </div>
                        <?php endif; ?>

                        <?php if (isset($_SESSION['error'])): ?>
                            <div class="alert alert-danger m-t-20" role="alert">
                                <?php
                                echo $_SESSION['error'];
                                unset($_SESSION['error']);
                                ?>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once 'layout/footer.php'; ?>
