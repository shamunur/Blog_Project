<?php

include_once 'inc/config.php';
include_once 'layout/header.php';

$edit_post_id = $_GET['id'];

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
}

$sql = "SELECT * FROM `blogs` WHERE `id` = $edit_post_id";
$query = mysqli_query($connect, $sql);
$result = mysqli_fetch_array($query);

if (isset($_POST['submit_comment'])) {
    $message = $_POST['message'];
    $user_id = $_POST['user_id'];
    $blog_id = $_POST['blog_id'];

    $sql = "INSERT INTO comments(message, user_id, blog_id) VALUES('$message', '$user_id', '$blog_id')";
    $run = mysqli_query($connect, $sql);
    if ($run) {
        $_SESSION['success'] = "Comment has been added";
        header('location: single_post.php?id=' . $blog_id);
    } else {
        $_SESSION['error'] = "Something went wrong";
        header('location: single_post.php?id=' . $blog_id);
    }
}

?>
    <div class="blog-single-section p-t-100 p-b-100">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="blog-details m-b-100">
                        <div class="thumb">
                            <img src="<?php echo $result['image']; ?>" alt="thumb">
                        </div>
                        <div class="content">
                            <div class="meta">
                                <div class="meta">
                                    <div class="category"><?php echo $result['categories'] ?></div>
                                    <div class="date"><?php echo date('d-M-Y', strtotime($result['created_date'])); ?></div>
                                </div>
                            </div>
                            <h2><?php echo $result['title']; ?></h2>
                            <div class="text">
                                <?php echo $result['content']; ?>
                            </div>
                            <div class="tags">
                                <?php echo $result['tags'] ?>
                            </div>
                        </div>
                    </div>

                    <div class="comment-list m-b-50">
                        <?php

                        $sql = "SELECT * FROM `comments`";
                        $run = mysqli_query($connect, $sql);
                        $rows = mysqli_num_rows($run);
                        if ($rows > 0) {
                            while ($row = mysqli_fetch_assoc($run)) {

                                $user_id = $row['user_id'];

                                $sql2 = "SELECT * FROM `users` WHERE `id` = $user_id";
                                $query2 = mysqli_query($connect, $sql2);
                                $result2 = mysqli_fetch_array($query2);


                                if ($row['blog_id'] == $edit_post_id):
                                    ?>
                                    <div class="comment-post">
                                        <?php if (!empty($result2['image'])): ?>
                                            <div class="thumb">
                                                <img src="<?php echo $result2['image']; ?>" alt="">
                                            </div>
                                        <?php endif; ?>
                                        <div class="content">
                                            <div class="date">
                                                <?php echo date('d-M-Y', strtotime($row['created_date'])); ?>
                                            </div>
                                            <div class="title">
                                                <?php echo $result2['username']; ?>
                                            </div>
                                            <div class="text">
                                                <?php echo $row['message']; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                                endif;
                            }
                        }
                        ?>
                    </div>

                    <div class="comment-form">
                        <div class="info">
                            <h2>Leave A Comment</h2>
                            <?php if (!isset($_SESSION['user_name'])): ?>
                                <p>You must be <a href="login.php">logged in</a> to post a comment.</p>
                            <?php endif; ?>
                        </div>
                        <?php if (isset($_SESSION['user_name'])): ?>
                            <div class="login-form">
                                <form action="" method="post" enctype="multipart/form-data">
                                    <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
                                    <input type="hidden" name="blog_id" value="<?php echo $edit_post_id; ?>">
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <?php if (isset($_SESSION['success'])): ?>
                                                <div class="alert alert-success m-t-20" role="alert">
                                                    <?php
                                                    echo $_SESSION['success'];
                                                    unset($_SESSION['success']);
                                                    ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (isset($_SESSION['error'])): ?>
                                                <div class="alert alert-danger m-t-20" role="alert">
                                                    <?php
                                                    echo $_SESSION['error'];
                                                    unset($_SESSION['error']);
                                                    ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-xl-12">
                                            <div class="input-wrap">
                                                <label for="message">Message</label>
                                                <textarea name="message" id="message" cols="30" rows="10"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-xl-12">
                                            <div class="input-btn">
                                                <button type="submit" name="submit_comment">Submit Comment</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php include_once 'layout/footer.php'; ?>